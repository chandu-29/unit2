﻿# GVI_unit2
# android-basics-kotlin-tip-calculator-app
<img width="960" alt="call" src="https://user-images.githubusercontent.com/83489094/187084575-62d50553-543d-4629-abdb-d5b6b7448eda.png">
<img width="960" alt="cal" src="https://user-images.githubusercontent.com/83489094/187084614-80b695e5-28ef-48b1-80b5-0b3e46fa0d86.png">
